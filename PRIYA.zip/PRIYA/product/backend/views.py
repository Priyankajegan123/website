from django.shortcuts import render

# Create your views here.
def train(request):
    return render(request,'cosmeticwebpage.html')

def cosmeticwebpage(request):
    return render(request,'cosmeticwebpage.html')


from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from .models import Customer
from django.views import View
from django.urls import reverse
from django.http import HttpResponseRedirect


class Login(View):
    return_url = None
    def get(self , request):
        Login.return_url = request.GET.get('return_url')
        return render(request , 'login.html')

    def post(self , request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id

                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('cosmeticwebpage')
            else:
                error_message = 'Email or Password invalid !!'
        else:
            error_message = 'Email or Password invalid !!'

        print(email, password)
        return render(request, 'login.html', {'error': error_message})

def logout(request):
    request.session.clear()
    return redirect('login')





from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from .models import Customer
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        username = postData.get('username')
        email = postData.get('email')
        password = postData.get('password')
        # validation
        value = {
            'username': username,
            'email': email
        }
        error_message = None

        customer = Customer(username=username,
                            email=email,
                            
                            password=password)
        error_message = self.validateCustomer(customer)

        if not error_message:
            print(username, email, password)
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('cosmeticwebpage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validateCustomer(self, customer):
        error_message = None;
        if (not customer.username):
            error_message = "First Name Required !!"
        elif len(customer.username) < 4:
            error_message = 'First Name must be 4 char long or more'
        elif len(customer.password) < 6:
            error_message = 'Password must be 6 char long'
        elif len(customer.email) < 5:
            error_message = 'Email must be 5 char long'
        elif customer.isExists():
            error_message = 'Email Address Already Registered..'
        # saving

        return error_message
    
