from django.db import models


# Create your models here.
class Customer(models.Model):
    username = models.CharField(max_length=50)
    email = models.EmailField()
    password = models.CharField(max_length=500)

    def isExists(self):
        return Customer.objects.filter(email=self.email).exists()



    def register(self):
        self.save()

    @staticmethod
    def get_customer_by_email(email):
         try:
              return Customer.objects.get(email=email)
         except:
              return False
         