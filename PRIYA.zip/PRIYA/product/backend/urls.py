from django.urls import path
from backend import views
from backend.views import train,Signup
from backend.views import cosmeticwebpage,Signup
from backend.views import cosmeticwebpage,Login


urlpatterns = [
   path('',views.train,name='train'),
   path('signup/',Signup.as_view(),name='signup'),
   path('cosmeticwebpage',views.cosmeticwebpage,name='cosmeticwebpage'),
   path('login/',Login.as_view(),name='login'),
]
