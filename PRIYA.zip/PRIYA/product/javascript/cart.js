window.onload = function() {
    displayCartItems(); 
    calculateTotal();  
};

function displayCartItems() {
  
    const cartItems = [
        { name: 'Lipstick', price: 100.00 },
        { name: 'Foundation', price: 200.00 },
        { name: 'Eyeliner', price: 250.00 },
    ];

    const cartContainer = document.getElementById('cart-items');
    cartContainer.innerHTML = ''; 

    cartItems.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.classList.add('cart-item');
        itemElement.innerHTML = `
            <h3>${item.name}</h3>
            <p>$${item.price.toFixed(2)}</p>
        `;
        cartContainer.appendChild(itemElement);
    });
}

function calculateTotal() {
   
    const cartItems = [
        { name: 'Lipstick', price: 100.00 },
        { name: 'Foundation', price: 200.00 },
        { name: 'Eyeliner', price: 250.00 },
    ];

    const totalAmount = cartItems.reduce((total, item) => total + item.price, 0);
    const totalElement = document.getElementById('total-amount');
    totalElement.textContent = `$${totalAmount.toFixed(2)}`;
}

function checkout() {
    alert('Proceeding to checkout...');
}