fetch('/login', {
    method: 'POST',
    body: new URLSearchParams(new FormData(document.getElementById('loginForm')))
}).then(response => response.json()).then(data => {
    if (data.role === 'vendor') {
        window.location.href = '/vendor-dashboard';
    } else {
        window.location.href = '/user-dashboard';
    }
});